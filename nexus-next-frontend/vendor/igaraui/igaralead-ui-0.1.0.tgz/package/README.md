# IgaraUI — Component Library

Biblioteca de componentes, tokens e layouts usados nas plataformas IgaraLead.
Ela usa shadcn/ui como base, mas publica uma API própria para que **Hub**, **Entity**, **Amplex** e **Nexus** compartilhem a mesma filosofia visual.

## Stack

- React 19 + TypeScript
- Vite 8 em library mode
- Tailwind CSS 4 + shadcn/ui (Radix) + `tw-animate-css` — tokens em `src/index.css`
- Lucide React (icones)
- React Router DOM apenas no catálogo de demonstração

## Setup

```bash
cd IgaraUI
npm install
npm run dev
```

## Consumo em Produtos

Depois de publicar ou apontar o pacote via workspace/git, importe o CSS uma vez no entrypoint do app consumidor:

```tsx
import '@igaralead/ui/styles.css'
```

Use os componentes pela API pública:

```tsx
import { Button, Card, CardContent, CardHeader, CardTitle, IgaraAppShell } from '@igaralead/ui'
```

Exemplo de layout compartilhado:

```tsx
import { IgaraAppShell, type IgaraNavItem } from '@igaralead/ui'
import '@igaralead/ui/styles.css'

const navItems: IgaraNavItem[] = [
  { href: '/', label: 'Dashboard' },
  { href: '/contatos', label: 'Contatos' },
]

export function App() {
  return (
    <IgaraAppShell
      activePath={window.location.pathname}
      brand="Entity"
      footerTitle="IgaraLead"
      navItems={navItems}
      subtitle="Plataforma Entity"
      userInitials="EN"
    >
      <main>Conteúdo da plataforma</main>
    </IgaraAppShell>
  )
}
```

## Scripts

```bash
npm run dev           # catálogo visual em Vite
npm run build         # biblioteca em dist/
npm run build:lib     # alias explícito do build da biblioteca
npm run build:catalog # build estático do catálogo
npm run lint          # ESLint
```

## API Pública

- `src/index.ts` é o único entrypoint público da biblioteca.
- `src/components/ui/` contém primitives shadcn customizados para IgaraLead.
- `src/components/layout/` contém layouts compartilhados, começando por `IgaraAppShell`.
- `src/lib/utils.ts` exporta `cn()` para composição de classes.
- `src/index.css` é o contrato de tokens, utilitários e tema.

## Seções do Catálogo

| Pagina       | O que mostra                                      |
|-------------|---------------------------------------------------|
| Visao Geral | Tokens rapidos + grid de navegacao                 |
| Cores       | Paleta completa: brand, surface, glass, semanticas |
| Tipografia  | Space Grotesk, Sansation, JetBrains Mono, escala   |
| Botoes      | `Button` shadcn: variantes e tamanhos              |
| Inputs      | Input, Select, Textarea, Checkbox, Switch, erro    |
| Cards       | `Card` shadcn, stats, hover                        |
| Badges      | `Badge`: success, warning, destructive, outline    |
| Tabelas     | `Table` shadcn, hover, valores financeiros       |
| Layout      | Navbar demo, sidebar, Tabs shadcn, breadcrumbs     |
| Modais      | `Dialog` Radix (shadcn)                            |
| Feedback    | `Alert`, loading, `Progress`, estado vazio         |

## Fonte de Tokens

A fonte de verdade dos tokens visuais e `src/index.css` (CSS-first).
Nao usamos `tailwind.config.cjs` como contrato de design system neste projeto.
Hub, Entity, Amplex e Nexus devem alinhar seus tokens ao contrato definido aqui.
